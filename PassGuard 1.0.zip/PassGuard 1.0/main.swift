//
//  main.swift
//  Slots
//
//  Created by Kristian Kocic on 16/5/2022.
//

import Foundation

populateArrayOfAccounts(Accounts_Array_String)
